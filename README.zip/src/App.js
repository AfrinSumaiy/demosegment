import React, { useState } from "react";
import SegmentModal from "./SegmentModal";
import { Drawer, Button, TextField, IconButton, Box, Typography } from "@mui/material";

function App() {
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);

  const handleSaveSegmentClick = () => {
    setIsDrawerOpen(true);
  };

  const handleCloseDrawer = () => {
    setIsDrawerOpen(false);
  };

  return (
    <div style={{ padding: "20px" }}>
      <Button
            variant="contained"
            onClick={handleSaveSegmentClick}
          >
            Save Segment
          </Button>
      <SegmentModal open={isDrawerOpen} onClose={handleCloseDrawer} />
    </div>
  );
}

export default App;
