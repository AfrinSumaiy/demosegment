import React, { useState } from "react";
import { Drawer, Button, TextField, IconButton, Box, Typography } from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import "./SegmentModal.css";

const SegmentModal = ({ open, onClose }) => {
  const [segmentName, setSegmentName] = useState("");
  const [selectedSchemas, setSelectedSchemas] = useState([]);
  const [newSchema, setNewSchema] = useState({ label: "", value: "" });

  const handleAddSchema = () => {
    if (!newSchema.label || !newSchema.value) {
      alert("Please fill in both Label and Value fields!");
      return;
    }

    setSelectedSchemas((prev) => [...prev, newSchema]);
    setNewSchema({ label: "", value: "" });
  };

  const handleRemoveSchema = (index) => {
    setSelectedSchemas((prev) =>
      prev.filter((_, schemaIndex) => schemaIndex !== index)
    );
  };

  const handleSaveSegment = async () => {
    const payload = {
      segment_name: segmentName,
      schema: selectedSchemas.map((schema) => ({
        [schema.value]: schema.label,
      })),
    };

    const webhookURL =
      "https://webhook.site/7ec5a4ac-1e14-498d-a531-89aeef612af3";

    try {
      const response = await fetch(webhookURL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      });

      if (response.ok) {
        alert("Segment saved successfully!");
        onClose();
      } else {
        alert("Failed to save segment.");
      }
    } catch (error) {
      console.error("Error saving segment:", error);
    }
  };

  return (
    <Drawer anchor="right" open={open} onClose={onClose}>
      <Box sx={{ width: 400, padding: "16px" }}>
        {/* <Box display="flex" justifyContent="space-between" alignItems="center">
          <Typography variant="h6">Save Segment</Typography>
          <IconButton onClick={onClose}>
            <CloseIcon />
          </IconButton>
        </Box> */}
        <Box
          display="flex"
          justifyContent="space-between"
          alignItems="center"
          sx={{ backgroundColor: "#d4edda", padding: "8px", borderRadius: "4px" }}
        >
          <Typography variant="h6" sx={{ color: "#155724" }}>
            Save Segment
          </Typography>
          <IconButton onClick={onClose}>
            <CloseIcon sx={{ color: "#155724" }} />
          </IconButton>
        </Box>

        <TextField
          fullWidth
          margin="normal"
          label="Name of the segment"
          value={segmentName}
          onChange={(e) => setSegmentName(e.target.value)}
        />

        <Typography variant="subtitle1" gutterBottom>
          Add Schema
        </Typography>

        <Box display="flex" gap={1} mb={2}>
          <TextField
            label="Label (e.g., First Name)"
            value={newSchema.label}
            onChange={(e) =>
              setNewSchema((prev) => ({ ...prev, label: e.target.value }))
            }
            fullWidth
          />
          <TextField
            label="Value (e.g., Tesa)"
            value={newSchema.value}
            onChange={(e) =>
              setNewSchema((prev) => ({ ...prev, value: e.target.value }))
            }
            fullWidth
          />
        </Box>

        <Button
          variant="contained"
          onClick={handleAddSchema}
          sx={{ marginBottom: "16px" }}
        >
          + Add Schema
        </Button>

        <Box>
          {selectedSchemas.map((schema, index) => (
            <Box
              key={index}
              display="flex"
              justifyContent="space-between"
              alignItems="center"
              sx={{ marginBottom: 1 }}
            >
              <Typography>
                {schema.label} : {schema.value}
              </Typography>
              <Button
                variant="text"
                color="error"
                onClick={() => handleRemoveSchema(index)}
              >
                Remove
              </Button>
            </Box>
          ))}
        </Box>

        <Box mt={2} display="flex" justifyContent="space-between">
          <Button
            variant="contained"
            onClick={handleSaveSegment}
            disabled={!segmentName || selectedSchemas.length === 0}
          >
            Save Segment
          </Button>
          <Button variant="outlined" onClick={onClose}>
            Cancel
          </Button>
        </Box>
      </Box>
    </Drawer>
  );
};

export default SegmentModal;
